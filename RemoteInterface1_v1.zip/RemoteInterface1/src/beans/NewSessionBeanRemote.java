/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import javax.ejb.Remote;

/**
 *
 * @author minju
 */
@Remote
public interface NewSessionBeanRemote {

    public void connection();

    public void insertMember(String userID, String password, String name, String email);

    boolean isInsertMemberSuccessful();
    
}
