/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;

/**
 *
 * @author minju
 */
@Stateless
public class NewSessionBean implements NewSessionBeanRemote, NewSessionBeanLocal {

    private String DRIVER = "org.apache.derby.jdbc.ClientDriver";
    private final String URL = "jdbc:derby://localhost:1527/sample";
    private String userName = "app";
    private String password = "app";
    private Connection con;
    private boolean insertMember = false;
    private boolean alreadyThere = false;

    @Override
    public void connection() {
        try {
            // load the database driver for MySQL
            Class.forName(DRIVER);
            System.out.println("Trying to open connection");
            con = (Connection) DriverManager.getConnection(URL, userName, password);

        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NewSessionBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public void insertMember(String userID, String password, String name, String email) {
        try {
            Statement stmt = con.createStatement();

            //Check if userID is already in the database
            String commandCheckID = "select user_id from members where user_id = '" + userID + "'";
            ResultSet rs = stmt.executeQuery(commandCheckID);

            if (rs == null) {
                String commandInsert = "insert into members (user_id, password, user_name, email) values ('" + userID + "', '" + password + "', '" + name + "', '" + email + "')";
                stmt.executeUpdate(commandInsert);
                System.out.println("Successfully updated row");
                insertMember = true;
            } else {
                insertMember = false;
                System.out.println("Inserting Member Unsucessful");
            }

        } catch (SQLException ex) {
            Logger.getLogger(NewSessionBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public boolean isInsertMemberSuccessful() {
        return insertMember;
    }

}
